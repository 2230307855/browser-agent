import{c as r,s as e}from"./flowDiagram-HODETNUW-DAeQX2SK.js";import{_ as a}from"./mermaid.core-DWSorE2c.js";import"./chunk-5VM5RSS4-DXXuT-dL.js";import"./chunk-XXDRQBXY-CNWu802G.js";import"./chunk-POPQ4Y6H-D2GM8jA_.js";import"./chunk-F27PBJKO-6R3bc8Z6.js";import"./message-renderer-ri5Gx5l6.js";import"./channel-CCtsmu5w.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
